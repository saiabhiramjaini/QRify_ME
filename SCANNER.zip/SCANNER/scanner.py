import cv2
import pyzbar.pyzbar as pyzbar
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import datetime
import pyttsx3
# C://flutter-application-myap-5fb99-firebase-adminsdk-s4mzf-3b259c6dc8.json
# Use your own Firebase credentials file
cred = credentials.Certificate("C:/ABHIRAM/PROJECT SCHOOL 2/SCANNER/qrifyme-222bc-firebase-adminsdk-44moh-2652e4a924.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# email_id = "thescript356@gmail.com"

# if check_if_email_exists(email_id):
#     print("yes")
# else:
#     print("no")


# Create an instance of the Text-to-Speech engine
engine = pyttsx3.init()

# Set the properties for the Text-to-Speech engine
engine.setProperty('rate', 150)  # Speed of the voice
engine.setProperty('volume', 1)  # Volume of the voice

# Create a border for the scanner
border_size = 50
border_color = (0, 255, 0)  # Green
border_thickness = 2

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    decoded_objects = pyzbar.decode(frame)
    
    # Add a border to the scanner
    frame = cv2.copyMakeBorder(frame, border_size, border_size, border_size, border_size, cv2.BORDER_CONSTANT, value=border_color)
    
    for obj in decoded_objects:
        # Check if the decoded object is a QR code
        if obj.type == "QRCODE":
            # Decode the data in the QR code
            try:
                qr_data = obj.data.decode()
                qr_date = datetime.datetime.strptime(qr_data[-26:], '%Y-%m-%d %H:%M:%S.%f')
                qr_id = str(qr_data[:-26])
                # Check if the QR code data exists in the Firebase database
                qr_doc = db.collection('events').where('timeStamp', '==', str(qr_date)).limit(1).get()
                qr_val = qr_doc[0]
                if qr_val.exists:
                    qr_data_dict = qr_val.to_dict()
                    db_date = datetime.datetime.strptime(qr_data_dict['timeStamp'], '%Y-%m-%d %H:%M:%S.%f')
                    if qr_date >= db_date:
                        print("Allowed")
                        engine.say("Allowed")
                        engine.runAndWait()
                        # Add the allowed QR code data to the Firebase database
                        entry_data = str(datetime.datetime.now())
                        parent_doc_ref = qr_doc[0].reference
                        # Get a reference to the "registeredUsers" subcollection
                        registered_users_ref = parent_doc_ref.collection('registeredUsers')

                        # Get a reference to the specific document within the subcollection
                        specific_doc_ref = registered_users_ref.where("email", "==", qr_id).get()

                        for doc in specific_doc_ref:
                            registered_user_ref = doc.reference
        
                            # Update the document by adding the "time" field
                            registered_user_ref.update({'time': entry_data})

                    else:
                        print("Event not yet started")
                        engine.say("Event not yet started")
                        engine.runAndWait()
                else:
                    print("No Data Found")
                    engine.say("No Data Found")
                    engine.runAndWait()
            except:
                print("invalid QR")
                engine.say("invalid QR")
                engine.runAndWait()

    cv2.imshow("QR Code Scanner", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()